--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tugas1;
--
-- Name: tugas1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tugas1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE tugas1 OWNER TO postgres;

\connect tugas1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eskul; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eskul (
    id_eskul integer NOT NULL,
    nama character varying NOT NULL
);


ALTER TABLE public.eskul OWNER TO postgres;

--
-- Name: eskul_id_eskul_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eskul_id_eskul_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.eskul_id_eskul_seq OWNER TO postgres;

--
-- Name: eskul_id_eskul_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eskul_id_eskul_seq OWNED BY public.eskul.id_eskul;


--
-- Name: kelas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kelas (
    id_kelas integer NOT NULL,
    tingkat character varying(12),
    nama_kelas character varying(50)
);


ALTER TABLE public.kelas OWNER TO postgres;

--
-- Name: kelas_id_kelas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kelas_id_kelas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kelas_id_kelas_seq OWNER TO postgres;

--
-- Name: kelas_id_kelas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kelas_id_kelas_seq OWNED BY public.kelas.id_kelas;


--
-- Name: kelas_murid; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kelas_murid (
    id_kelas integer NOT NULL,
    nis integer NOT NULL
);


ALTER TABLE public.kelas_murid OWNER TO postgres;

--
-- Name: murid; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.murid (
    nis integer NOT NULL,
    nama character varying(50),
    jenis_kelamin character varying(10)
);


ALTER TABLE public.murid OWNER TO postgres;

--
-- Name: murid_eskul; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.murid_eskul (
    id_eskul integer NOT NULL,
    nis integer NOT NULL
);


ALTER TABLE public.murid_eskul OWNER TO postgres;

--
-- Name: murid_nis_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.murid_nis_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.murid_nis_seq OWNER TO postgres;

--
-- Name: murid_nis_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.murid_nis_seq OWNED BY public.murid.nis;


--
-- Name: sekolah; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sekolah (
    id_sekolah integer NOT NULL,
    nama_sekolah character varying(50)
);


ALTER TABLE public.sekolah OWNER TO postgres;

--
-- Name: sekolah_kelas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sekolah_kelas (
    id_sekolah integer NOT NULL,
    id_kelas integer NOT NULL
);


ALTER TABLE public.sekolah_kelas OWNER TO postgres;

--
-- Name: eskul id_eskul; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eskul ALTER COLUMN id_eskul SET DEFAULT nextval('public.eskul_id_eskul_seq'::regclass);


--
-- Name: kelas id_kelas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kelas ALTER COLUMN id_kelas SET DEFAULT nextval('public.kelas_id_kelas_seq'::regclass);


--
-- Name: murid nis; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.murid ALTER COLUMN nis SET DEFAULT nextval('public.murid_nis_seq'::regclass);


--
-- Data for Name: eskul; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eskul (id_eskul, nama) FROM stdin;
\.
COPY public.eskul (id_eskul, nama) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: kelas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kelas (id_kelas, tingkat, nama_kelas) FROM stdin;
\.
COPY public.kelas (id_kelas, tingkat, nama_kelas) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: kelas_murid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kelas_murid (id_kelas, nis) FROM stdin;
\.
COPY public.kelas_murid (id_kelas, nis) FROM '$$PATH$$/3372.dat';

--
-- Data for Name: murid; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.murid (nis, nama, jenis_kelamin) FROM stdin;
\.
COPY public.murid (nis, nama, jenis_kelamin) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: murid_eskul; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.murid_eskul (id_eskul, nis) FROM stdin;
\.
COPY public.murid_eskul (id_eskul, nis) FROM '$$PATH$$/3373.dat';

--
-- Data for Name: sekolah; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sekolah (id_sekolah, nama_sekolah) FROM stdin;
\.
COPY public.sekolah (id_sekolah, nama_sekolah) FROM '$$PATH$$/3370.dat';

--
-- Data for Name: sekolah_kelas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sekolah_kelas (id_sekolah, id_kelas) FROM stdin;
\.
COPY public.sekolah_kelas (id_sekolah, id_kelas) FROM '$$PATH$$/3371.dat';

--
-- Name: eskul_id_eskul_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eskul_id_eskul_seq', 7, true);


--
-- Name: kelas_id_kelas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kelas_id_kelas_seq', 15, true);


--
-- Name: murid_nis_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.murid_nis_seq', 20, true);


--
-- Name: eskul eskul_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eskul
    ADD CONSTRAINT eskul_pkey PRIMARY KEY (id_eskul);


--
-- Name: kelas_murid kelas_murid_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kelas_murid
    ADD CONSTRAINT kelas_murid_pk PRIMARY KEY (id_kelas, nis);


--
-- Name: kelas kelas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kelas
    ADD CONSTRAINT kelas_pkey PRIMARY KEY (id_kelas);


--
-- Name: murid_eskul murid_eskul_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.murid_eskul
    ADD CONSTRAINT murid_eskul_pk PRIMARY KEY (id_eskul, nis);


--
-- Name: murid murid_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.murid
    ADD CONSTRAINT murid_pkey PRIMARY KEY (nis);


--
-- Name: sekolah_kelas sekolah_kelas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sekolah_kelas
    ADD CONSTRAINT sekolah_kelas_pk PRIMARY KEY (id_sekolah, id_kelas);


--
-- Name: sekolah sekolah_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sekolah
    ADD CONSTRAINT sekolah_pkey PRIMARY KEY (id_sekolah);


--
-- Name: murid_eskul fk_eskul; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.murid_eskul
    ADD CONSTRAINT fk_eskul FOREIGN KEY (id_eskul) REFERENCES public.eskul(id_eskul);


--
-- Name: sekolah_kelas fk_kelas; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sekolah_kelas
    ADD CONSTRAINT fk_kelas FOREIGN KEY (id_kelas) REFERENCES public.kelas(id_kelas);


--
-- Name: kelas_murid fk_kelas; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kelas_murid
    ADD CONSTRAINT fk_kelas FOREIGN KEY (id_kelas) REFERENCES public.kelas(id_kelas);


--
-- Name: kelas_murid fk_murid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kelas_murid
    ADD CONSTRAINT fk_murid FOREIGN KEY (nis) REFERENCES public.murid(nis);


--
-- Name: murid_eskul fk_murid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.murid_eskul
    ADD CONSTRAINT fk_murid FOREIGN KEY (nis) REFERENCES public.murid(nis);


--
-- Name: sekolah_kelas fk_sekolah; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sekolah_kelas
    ADD CONSTRAINT fk_sekolah FOREIGN KEY (id_sekolah) REFERENCES public.sekolah(id_sekolah);


--
-- PostgreSQL database dump complete
--

